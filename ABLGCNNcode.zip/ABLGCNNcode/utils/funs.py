import json
import numpy as np
import sys

# 读取json文件的数据
def load_json(filename):
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data
    except IOError:
        raise "ERROR: Unable to locate file {}".format(filename)

def dump_to_json(dataset, filename):
    """Save built dataset into json"""
    if dataset is not None:
        with open(filename, 'w') as f:
            json.dump(dataset, f)
        sys.stdout.write('dump dataset to {}.\n'.format(filename))

# 读取每个idx对应的向量
def load_embeddings(filename):
    try:
        with np.load(filename) as data:
            return data['embeddings']
    except IOError:
        raise 'ERROR: Unable to locate file {}.'.format(filename)


def batch_iter(dataset, batch_size, dataset_name=1):
    batch_x, batch_y,x = [], [], []
    for record in dataset:
        if len(batch_x) == batch_size:
            yield batch_x, batch_y
            batch_x, batch_y = [], []
        if dataset_name == 1:
            x = [tuple(value) for value in record["sentence"]]
            x = zip(*x)
        else:
            x = record["sentence"]
        y = record["label"]
        batch_x += [x]
        batch_y += [y]
    if len(batch_x) != 0:
        yield batch_x, batch_y


def _pad_sequences(sequences, pad_tok, max_length):
    """Args:
        sequences: a generator of list or tuple
        pad_tok: the char to pad with
    Returns:
        a list of list where each sublist has same length
    """
    sequence_padded, sequence_length = [], []
    for seq in sequences:
        seq = list(seq)
        if len(seq) < max_length:
            seq_ = seq[:max_length] + [pad_tok] * max(max_length - len(seq), 0)
        else:
            seq_ = seq[:max_length]
        sequence_padded += [seq_]
        sequence_length += [min(len(seq), max_length)]
    return sequence_padded, sequence_length


def pad_sequences(sequences, max_length, pad_tok):
    """Args:
        sequences: a generator of list or tuple
        max_length: maximal length for a sentence allowed
        max_length_2: maximal length for a word allow, only for nLevels=2
        pad_tok: the char to pad with
        nlevels: depth of padding, 2 for the case where we have characters ids
    Returns:
        a list of list where each sublist has same length
    """
    sequence_padded = []
    for seq in sequences:
        seq = list(seq)
        if len(seq) < max_length:
            seq_ = seq[:max_length] + [pad_tok] * max(max_length - len(seq), 0)
        else:
            seq_ = seq[:max_length]
        sequence_padded += [seq_]
    return sequence_padded

def deal_with_report(report):
    res = []
    lines = report.split("\n")
    for line in lines[2:]:
        line = line.replace("avg / total", "avg/total ")
        row = line.split()
        if row != []:
            res.append(row)
    return res

def split_train_dev_test(dataset, dev_ratio=0.1, test_ratio=0.1, build_test=True, shuffle=True):
    """Split dataset into train, dev as well as test sets"""
    if shuffle:
        np.random.shuffle(dataset)
    data_size = len(dataset)
    if build_test:
        train_position = int(data_size * (1 - dev_ratio - test_ratio))
        dev_position = int(data_size * (1 - test_ratio))
        train_set = dataset[:train_position]
        dev_set = dataset[train_position:dev_position]
        test_set = dataset[dev_position:]
        return train_set, dev_set, test_set
    else:
        # dev_ratio = dev_ratio + test_ratio
        train_position = int(data_size * (1 - dev_ratio))
        train_set = dataset[:train_position]
        dev_set = dataset[train_position:]
        return train_set, dev_set, None