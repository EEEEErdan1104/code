import os
import re
import sys
import json
import codecs
import operator
import numpy as np
# tqdm主要是用来显示进度条
from tqdm import tqdm
from gensim.models.keyedvectors import KeyedVectors

np.random.seed(1234)
special_chars = re.compile(r'[^A-Za-z_\d,.?!;:$\- \'\"]', re.IGNORECASE)

# 所有原有数据路径
source_dir = os.path.join(".", "raw")
# 词嵌入的google的数据集
emb_dir = os.path.join(".", "embedding")
# 最终的目标数据产生的位置
target_dir = os.path.join(".", "data")

# special tokens
PAD = '__PAD__'
UNK = '__UNK__'


def clean_text(text):
    """Remove special tokens and clean up text"""
    text = text.replace("``", '"').replace("''", '"').replace("`", "'")  # convert quote symbols
    text = text.replace("n 't", "n't").replace("can not", "cannot")
    text = special_chars.sub(' ', text)
    text = re.sub(' +', ' ', text)
    text = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", text)
    text = re.sub(r"\'s", " \'s", text)
    text = re.sub(r"\'ve", " \'ve", text)
    text = re.sub(r"n\'t", " n\'t", text)
    text = re.sub(r"\'re", " \'re", text)
    text = re.sub(r"\'d", " \'d", text)
    text = re.sub(r"\'ll", " \'ll", text)
    text = re.sub(r",", " , ", text)
    text = re.sub(r"!", " ! ", text)
    text = re.sub(r"\(", " \( ", text)
    text = re.sub(r"\)", " \) ", text)
    text = re.sub(r"\?", " \? ", text)
    text = re.sub(r"\s{2,}", " ", text)
    return text.strip().lower()



def load_glove_vocab(filename):
    """Read glove word vocabulary from embeddings"""
    with open(filename, 'r', encoding='utf-8') as f:
        vocab = {line.strip().split()[0] for line in tqdm(f, desc='Loading GloVe vocabularies')}
    print('\t -- totally {} tokens in GloVe embeddings.\n'.format(len(vocab)))
    return vocab


def load_word2vec_vocab(filename):
    """Read word2vec word vocabulary from embeddings"""
    google_bin = KeyedVectors.load_word2vec_format(filename, binary=True)
    # google all word vectors
    vocab = google_bin.wv.vocab
    print('\t -- totally {} tokens in word2vec embeddings.\n'.format(len(vocab)))
    return set(vocab)


def load_data(filename, clean=True, encoding='utf-8'):
    """Read data from file into list of tuples
       返回到数据sentence是一个列表，label是一个int类型
       dataset是所有文本数据的列表
    """
    dataset = []
    labels = set()
    with codecs.open(filename, 'r', encoding=encoding) as f:
        for line in f:
            line = line.lower()
            if encoding is not 'utf-8':
                line = line.encode('utf-8').decode(encoding)  # convert string to utf-8 version
            line = line.strip().split(' ')  # all the tokens and labels are split by __BLANKSPACE__
            if clean:
                sentence = clean_text(' '.join(line[1:])).split(' ')  # clean text and convert to tokens again
            else:
                sentence = line[1:]
            label = int(line[0])
            labels.add(label)
            # sentence 的结果是一个列表
            dataset.append((sentence, label))
    return dataset, len(labels)


def build_vocab(datasets, threshold=0):
    """Build word and char vocabularies
        datasets是train和dev的两个数据集的列表
        words是每个文本的列表
    """
    word_count = dict()
    char_vocab = set()
    for dataset in datasets:
        for words, _ in dataset:
            for word in words:
                # char这个集合中添加字符级别，有则不加，没有则加入
                char_vocab.update(word)  # update char vocabulary
                # word_count中word的这个词次数加1
                word_count[word] = word_count.get(word, 0) + 1  # update word count in word dict
    word_count = reversed(sorted(word_count.items(), key=operator.itemgetter(1)))
    word_vocab = set([w[0] for w in word_count if w[1] >= threshold])
    char_vocab = char_vocab
    return word_vocab, char_vocab


def write_vocab(vocab, filename):
    """write vocabulary to file"""
    if os.path.exists(filename):
        pass
    else:
        sys.stdout.write('Writing vocab to {}...'.format(filename))
        with open(filename, 'w') as f:
            for i, word in enumerate(vocab):
                f.write('{}\n'.format(word)) if i < len(vocab) - 1 else f.write(word)
        sys.stdout.write(' done. Totally {} tokens.\n'.format(len(vocab)))


def load_vocab(filename):
    """read vocabulary from file into dict"""
    word_idx = dict()
    idx_word = dict()
    with open(filename, 'r', encoding='utf-8') as f:
        for idx, word in enumerate(f):
            word = word.strip()
            word_idx[word] = idx
            idx_word[idx] = word
    return word_idx, idx_word


def save_filtered_vectors(word_idx, gw_path, save_path, word_dim, vec_method):
    """Prepare pre-trained word embeddings for dataset"""
    embeddings = np.zeros([len(word_idx), word_dim])  # embeddings[0] for PAD
    scale = np.sqrt(3.0 / word_dim)
    embeddings[1] = np.random.uniform(-scale, scale, [1, word_dim])  # for UNK
    if vec_method == "glove":
        with open(gw_path, 'r', encoding='utf-8') as f:
            for line in tqdm(f, desc='Filtering GloVe embeddings'):
                line = line.strip().split(' ')
                word = line[0]
                embedding = [float(x) for x in line[1:]]
                if word in word_idx:
                    idx = word_idx[word]
                    embeddings[idx] = np.asarray(embedding)
    else:
        word2vec = KeyedVectors.load_word2vec_format(gw_path, binary=True)
        for word in word_idx.keys():
            if word in word2vec.vocab:
                idx = word_idx[word]
                embeddings[idx] = np.asarray(word2vec[word])
    sys.stdout.write('Saving filtered embeddings...')
    np.savez_compressed(save_path, embeddings=embeddings)
    sys.stdout.write(' done.\n')


def fit_word_to_id(word, word_vocab, char_vocab):
    """Convert word str to word index and char indices"""
    char_ids = []
    for char in word:
        char_ids += [char_vocab[char]] if char in char_vocab else [char_vocab[UNK]]
    word = word_vocab[word] if word in word_vocab else word_vocab[UNK]
    return word, char_ids


def dump_to_json(dataset, filename):
    """Save built dataset into json"""
    if dataset is not None:
        with open(filename, 'w') as f:
            json.dump(dataset, f)
        sys.stdout.write('dump dataset to {}.\n'.format(filename))


def split_train_dev_test(dataset, dev_ratio=0.1, test_ratio=0.1, build_test=True, shuffle=True):
    """Split dataset into train, dev as well as test sets"""
    if shuffle:
        np.random.shuffle(dataset)
    data_size = len(dataset)
    if build_test:
        train_position = int(data_size * (1 - dev_ratio - test_ratio))
        dev_position = int(data_size * (1 - test_ratio))
        train_set = dataset[:train_position]
        dev_set = dataset[train_position:dev_position]
        test_set = dataset[dev_position:]
        return train_set, dev_set, test_set
    else:
        # dev_ratio = dev_ratio + test_ratio
        train_position = int(data_size * (1 - dev_ratio))
        train_set = dataset[:train_position]
        dev_set = dataset[train_position:]
        return train_set, dev_set, None


def build_dataset(raw_dataset, filename, word_idx, char_idx, num_labels, one_hot=True):
    """Convert dataset into word/char index, make labels to be one hot vectors and dump to json file"""
    dataset = []
    for sentence, label in raw_dataset:
        words = []
        for word in sentence:
            words += [fit_word_to_id(word, word_idx, char_idx)]
        if one_hot:
            label = [1 if i == label else 0 for i in range(num_labels)]
        dataset.append({'sentence': words, 'label': label})
    dump_to_json(dataset, filename=filename)


def prepro_general(train_set, dev_set, test_set, num_labels, data_folder, gw_vocab, gw_path, vec_method):
    """Performs to build vocabularies and processed dataset"""
    # build vocabularies（两个词集合）
    word_vocab, char_vocab = build_vocab([train_set, dev_set])  # only process train and dev sets
    if gw_vocab is None:
        if vec_method == "glove":
            gw_vocab = load_glove_vocab(gw_path)
        else:
            gw_vocab = load_word2vec_vocab(gw_path)
    # 将数据与glove_vocab找到都存在的词,并写入对应数据集的words.vocab中
    word_vocab = [PAD, UNK] + list(word_vocab & gw_vocab)  # distinct vocab and add PAD and UNK tokens
    write_vocab(word_vocab, filename=os.path.join(data_folder, 'words.vocab'))
    # 直接写入当前文本数据的字级别vocab
    char_vocab = [PAD, UNK] + list(char_vocab)  # add PAD and UNK tokens
    write_vocab(char_vocab, filename=os.path.join(data_folder, 'chars.vocab'))
    # build embeddings(创建当前文本每个词的index,用于后面的词嵌入)
    # word_idx是字典形式{word: idx}
    word_idx, _ = load_vocab(os.path.join(data_folder, 'words.vocab'))
    # 保存该数据中所有词对应的向量
    save_filtered_vectors(word_idx, gw_path, os.path.join(data_folder, '{}.filtered.npz'.format(vec_method)),
                          word_dim=300, vec_method=vec_method)
    # build dataset
    char_idx, _ = load_vocab(os.path.join(data_folder, 'chars.vocab'))
    # 创建的json文件包含了{'sentence':[word_idx, [char_idxs]], 'label':[0,0,1]}
    build_dataset(train_set, os.path.join(data_folder, 'train.json'), word_idx, char_idx, num_labels=num_labels,
                  one_hot=True)
    build_dataset(dev_set, os.path.join(data_folder, 'dev.json'), word_idx, char_idx, num_labels=num_labels,
                  one_hot=True)
    build_dataset(test_set, os.path.join(data_folder, 'test.json'), word_idx, char_idx, num_labels=num_labels,
                  one_hot=True)
    # save number of labels information into json
    # num_labels是对应的所有的训练文本的标签值
    with open(os.path.join(data_folder, 'label.json'), 'w') as f:
        json.dump({"label_size": num_labels}, f)


def prepro_sst(gw_path, vec_method, gw_vocab=None, mode=1):
    print('Process sst{} dataset...'.format(mode))
    data_folder = os.path.join(target_dir, 'sst{}_{}'.format(mode, vec_method))
    if not os.path.exists(data_folder):
        os.makedirs(data_folder)
    # load dataset
    name = 'fine' if mode == 1 else 'binary'
    # 读取原始数据并切词等处理
    train_set, num_labels = load_data(os.path.join(source_dir, 'sst{}'.format(mode), 'stsa.{}.train'.format(name)))
    dev_set, _ = load_data(os.path.join(source_dir, 'sst{}'.format(mode), 'stsa.{}.dev'.format(name)))
    test_set, _ = load_data(os.path.join(source_dir, 'sst{}'.format(mode), 'stsa.{}.test'.format(name)))
    # build general
    prepro_general(train_set, dev_set, test_set, num_labels, data_folder, gw_vocab, gw_path, vec_method)
    print()


def prepro_trec(gw_path, vec_method, gw_vocab=None):
    print('Process trec dataset...')
    data_folder = os.path.join(target_dir, 'trec_{}'.format(vec_method))
    if not os.path.exists(data_folder):
        os.makedirs(data_folder)
    # load dataset
    train_set, num_labels = load_data(os.path.join(source_dir, 'trec', 'TREC.train.all'), encoding='windows-1252')
    test_set, _ = load_data(os.path.join(source_dir, 'trec', 'TREC.test.all'))
    train_set, dev_set, _ = split_train_dev_test(train_set, build_test=False)
    # build general
    prepro_general(train_set, dev_set, test_set, num_labels, data_folder, gw_vocab, gw_path, vec_method)
    print()


def prepro_other(name, filename, vec_method, gw_path, gw_vocab=None, encoding='utf-8'):
    print('Process {} dataset...'.format(name))
    data_folder = os.path.join(target_dir, name + "_" + vec_method)
    if not os.path.exists(data_folder):
        os.makedirs(data_folder)
    # load dataset
    train_set, num_labels = load_data(os.path.join(source_dir, name, filename), encoding=encoding)
    train_set, dev_set, test_set = split_train_dev_test(train_set)
    # build general
    prepro_general(train_set, dev_set, test_set, num_labels, data_folder, gw_vocab, gw_path, vec_method)
    print()


def main(vec_method="glove"):
    if vec_method == "glove":
        # glove 向量化的方法
        glove_path = os.path.join(".", "emb_dir", "glove.42B.300d.txt")
        glove_vocab = load_glove_vocab(glove_path)
        # process sst1 dataset(预处理sst1的数据集)
        prepro_sst(glove_path, vec_method, glove_vocab, mode=1)
        # process sst2 dataset(预处理sst2的数据集)
        prepro_sst(glove_path, vec_method, glove_vocab, mode=2)
        # process trec dataset
        prepro_trec(glove_path, vec_method, glove_vocab)
        # process subj dataset
        prepro_other('subj', 'subj.all', vec_method, glove_path, glove_vocab, encoding='windows-1252')
        # process mr dataset
        prepro_other('mr', 'rt-polarity.all', vec_method, glove_path, glove_vocab, encoding='windows-1252')
        # process mpqa dataset
        prepro_other('mpqa', 'mpqa.all', vec_method, glove_path, glove_vocab)
        # process cr dataset
        prepro_other('cr', 'custrev.all', vec_method, glove_path, glove_vocab)
        print('Glove Pre-processing all the datasets finished... data is located at {}'.format(target_dir))
    else:
        # word2vec 向量化的方法
        word2vec_path = os.path.join(".", "emb_dir", "GoogleNews-vectors-negative300.bin")
        word2vec_vocab = load_word2vec_vocab(word2vec_path)
        # process sst1 dataset(预处理sst1的数据集)
        prepro_sst(word2vec_path, vec_method, word2vec_vocab, mode=1)
        # process sst2 dataset(预处理sst2的数据集)
        prepro_sst(word2vec_path, vec_method, word2vec_vocab, mode=2)
        # process trec dataset
        prepro_trec(word2vec_path, vec_method, word2vec_vocab)
        # process subj dataset
        prepro_other('subj', 'subj.all', vec_method, word2vec_path, word2vec_vocab, encoding='windows-1252')
        # process mr dataset
        prepro_other('mr', 'rt-polarity.all', vec_method, word2vec_path, word2vec_vocab, encoding='windows-1252')
        # process mpqa dataset
        prepro_other('mpqa', 'mpqa.all', vec_method, word2vec_path, word2vec_vocab)
        # process cr dataset
        prepro_other('cr', 'custrev.all', vec_method, word2vec_path, word2vec_vocab)
        print('Word2Vec Pre-processing all the datasets finished... data is located at {}'.format(target_dir))


if __name__ == "__main__":
    main("word2vec")
