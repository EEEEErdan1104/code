import tensorflow as tf
import os
import numpy as np
from utils import get_logger, batch_iter, pad_sequences, deal_with_report
from sklearn.metrics import classification_report


class ARCNN(object):
    def __init__(self, config, num_classes, batch_size=200, seq_length=None, resume_training=True, model_name="ARCNN"):
        # 参数/模型名称/恢复训练
        self.cfg, self.model, self.resume_training = config, model_name, resume_training
        self.start_epoch = 1
        self.batch_size = batch_size
        self.num_classes = num_classes
        self.seq_len = seq_length
        self.logger = get_logger(os.path.join(self.cfg.ckpt_path, 'log.txt'))
        # 建模
        self._add_placeholder()
        self._add_embedding_lookup()
        self._build_model()
        self._add_loss_op()
        self._add_accuracy()
        self._add_train_op()
        print('params number: {}'.format(np.sum([np.prod(v.get_shape().as_list()) for v in tf.trainable_variables()])))
        # initialize model
        self.sess, self.saver = None, None
        self.initialize_session()

    # 设置占位符
    def _add_placeholder(self):
        # shape=(batch_size, seq_len)
        self.word_idxs = tf.placeholder(tf.int32, shape=[None, None], name="word_idxs")
        # shape=(batch_size, label_size)
        self.labels = tf.placeholder(tf.int32, [None, None], name="labels")
        self.sentence_length = tf.placeholder(tf.int32, [None], name="sentence_length")
        # 超参数
        self.lr = tf.placeholder(tf.float32, name="learning_rate")
        self.is_train = tf.placeholder(tf.bool, shape=[], name="is_train")
        self.dropout_keep_prob = tf.placeholder(tf.float32, name='drop_keep_prob')

    # 初始化Session
    def initialize_session(self):
        self.sess = tf.Session()
        # 保存最近的max_to_keep个checkpoint文件数
        self.saver = tf.train.Saver(max_to_keep=self.cfg.max_to_keep)
        self.sess.run(tf.global_variables_initializer())
        if self.resume_training:
            checkpoint = tf.train.get_checkpoint_state(self.cfg.ckpt_path)
            # 如果不存在已经训练好的模型，询问是否继续训练
            if not checkpoint:
                r = input("No checkpoint found in directory %s, cannot resume training. Do you want to start a new "
                          "training session?\n(y)es | (n)o: " % self.cfg.ckpt_path)
                if r.startswith('y'):
                    return
                else:
                    exit(0)
            print('Resume training from %s...' % self.cfg.ckpt_path)
            ckpt_path = checkpoint.model_checkpoint_path
            self.start_epoch = int(ckpt_path.split('-')[-1]) + 1
            print('Start Epoch: ', self.start_epoch)
            self.saver.restore(self.sess, ckpt_path)

    # 恢复训练Session
    def restore_last_session(self, ckpt_path=None):
        if ckpt_path is not None:
            ckpt = tf.train.get_checkpoint_state(ckpt_path)
        else:
            ckpt = tf.train.get_checkpoint_state(self.cfg.ckpt_path)  # get checkpoint state
        if ckpt and ckpt.model_checkpoint_path:  # restore session
            self.saver.restore(self.sess, ckpt.model_checkpoint_path)

    # 保存模型的参数
    def save_session(self, epoch):
        if not os.path.exists(self.cfg.ckpt_path):
            os.makedirs(self.cfg.dir_model)
        self.saver.save(self.sess, self.cfg.ckpt_path + "_TextCNN", global_step=epoch)

    # 关闭Session
    def close_session(self):
        self.sess.close()

    # 词嵌入
    def _add_embedding_lookup(self):
        with tf.variable_scope('word_embeddings'):
            # 是否使用词嵌入方法，word_emb 是每个词对应的词向量
            if self.cfg.use_word_emb:
                _word_emb = tf.Variable(self.cfg.word_emb, name='_word_emb', trainable=self.cfg.finetune_emb,
                                        dtype=tf.float32)
            else:
                _word_emb = tf.get_variable(name='_word_emb', shape=[self.cfg.vocab_size, self.cfg.word_dim],
                                            trainable=True, dtype=tf.float32)
            self.word_emb = tf.nn.embedding_lookup(_word_emb, self.word_idxs, name='word_emb')
            # self.word_emb：当前批次的文档矩阵，[batch_size, seq_len]
            # self.word_emb = tf.expand_dims(word_emb, -1)

    def _get_feed_dict(self, sentences, dataset_name=1, labels=None, lr=None, is_train=None):
        """
        :param sentences: 每个句子表示词id的list集合
        :param labels: one-hot编码格式的labels
        :param lr: 学习率
        :param is_train: 是否进行训练
        :return: feed_dict
        """
        if dataset_name == 1:
            word_ids, _ = zip(*sentences)
        else:
            word_ids = tuple(sentences)
        word_ids = pad_sequences(word_ids, max_length=self.seq_len, pad_tok=0)
        feed_dict = {self.word_idxs: word_ids}
        if labels is not None:
            feed_dict[self.labels] = labels
        if lr is not None:
            feed_dict[self.lr] = lr
        if is_train is not None:
            feed_dict[self.is_train] = is_train
            feed_dict[self.dropout_keep_prob] = self.cfg.dropout_keep_prob
        else:
            feed_dict[self.is_train] = is_train
            feed_dict[self.dropout_keep_prob] = 1.0
        return feed_dict

    def _build_model(self):
        with tf.name_scope("Forward_LSTM"):
            fw_cell = tf.nn.rnn_cell.BasicLSTMCell(self.cfg.hidden_units, forget_bias=1.0, state_is_tuple=True)
            fw_cell = tf.nn.rnn_cell.DropoutWrapper(fw_cell, input_keep_prob=1.0,
                                                    output_keep_prob=self.dropout_keep_prob)
        with tf.name_scope("Back_LSTM"):
            bw_cell = tf.nn.rnn_cell.BasicLSTMCell(self.cfg.hidden_units, forget_bias=1.0, state_is_tuple=True)
            bw_cell = tf.nn.rnn_cell.DropoutWrapper(bw_cell, input_keep_prob=1.0,
                                                    output_keep_prob=self.dropout_keep_prob)
        (fw_out, bw_out), state = tf.nn.bidirectional_dynamic_rnn(fw_cell, bw_cell, self.word_emb,
                                                                  dtype=tf.float32, time_major=True)

        with tf.name_scope("context"):
            shape = [tf.shape(fw_out)[0], 1, tf.shape(fw_out)[2]]
            c_left = tf.concat([tf.zeros(shape), fw_out[:, :-1]], axis=1, name="context_left")
            c_right = tf.concat([bw_out[:, 1:], tf.zeros(shape)], axis=1, name="context_right")

        with tf.name_scope("word-representation"):
            self.x = tf.concat([c_left, self.word_emb, c_right], axis=2, name="x")
            embedding_sizes = 2 * self.cfg.hidden_units + self.cfg.word_dim

        with tf.name_scope("text-representation"):
            W_1 = tf.Variable(tf.random_uniform([embedding_sizes, self.cfg.word_dim], -1.0, 1.0), name="W_1")
            b_1 = tf.Variable(tf.constant(0.1, shape=[self.cfg.word_dim]), name="b_1")
            self.y2 = tf.tanh(tf.einsum("aij,jk->aik", self.x, W_1) + b_1)  # [batch_size, sequence_len, word_dim]
        # self.outputs_bl = tf.concat([fw_out, bw_out], axis=-1)  # [batch_size, seq_len, 2 * hidden_units]
        # self.outputs_bl = tf.transpose(self.outputs_bl, perm=[0, 2, 1])
        self.outputs_bls = tf.reshape(self.y2,
                                     shape=[self.batch_size, self.seq_len, self.cfg.word_dim, 1])
        with tf.name_scope("CNN"):
            self.W_cnn = tf.get_variable("W_cnn", shape=[1, self.cfg.word_dim, 1, self.cfg.num_filters],
                                         initializer=tf.contrib.layers.xavier_initializer())
            self.b_cnn = tf.Variable(tf.constant(0.1, shape=[self.cfg.num_filters]), name="b_cnn")
            # [batch_size, seq_length,1, num_filters]
            conv = tf.nn.conv2d(self.outputs_bls, self.W_cnn, strides=[1, 1, 1, 1], padding="VALID")
            self.conv = tf.nn.relu(tf.nn.bias_add(conv, self.b_cnn), name="relu_conv")
            self.conv = tf.reshape(self.conv, shape=[self.batch_size, self.seq_len, self.cfg.num_filters])
        # [batch_size, seq_length, 1, 2 * hidden_units + num_filter] [50, 256, 384]
        # self.conv_bl_out = tf.concat([self.outputs_bl, self.conv], axis=-1)

        with tf.name_scope("Attention"):
            self.W_a = tf.Variable(tf.truncated_normal([self.batch_size, self.cfg.num_filters, 1], stddev=0.1),
                                   name="W_a")
            self.b_a = tf.Variable(tf.constant(0.1, shape=[self.batch_size, self.seq_len, 1]), name="b_a")
            self.a = tf.tanh(tf.matmul(self.conv, self.W_a) + self.b_a)
            self.alpha = tf.nn.softmax(self.a)
            self.V = tf.reduce_mean(self.conv * self.alpha, axis=1)


    def _add_loss_op(self):
        l2_loss = tf.constant(0.0)
        W3 = tf.Variable(tf.truncated_normal(shape=[self.cfg.num_filters, self.num_classes], stddev=0.1), name="W3")
        b3 = tf.Variable(tf.constant(0.1, shape=[self.num_classes], name="b3"))
        l2_loss += tf.nn.l2_loss(W3)
        l2_loss += tf.nn.l2_loss(b3)
        self.predictions = tf.nn.xw_plus_b(self.V, W3, b3, name="predictions")
        losses = tf.nn.softmax_cross_entropy_with_logits(logits=self.predictions, labels=self.labels)
        self.loss = tf.reduce_mean(losses) + self.cfg.l2_reg * l2_loss

    def _add_accuracy(self):
        correct_predictions = tf.equal(tf.argmax(self.predictions, 1), tf.argmax(self.labels, 1))
        self.accuracy = tf.reduce_mean(tf.cast(correct_predictions, "float"))

    def _add_train_op(self):
        with tf.variable_scope("train_step"):
            optimizer = tf.train.AdamOptimizer(learning_rate=self.lr)
            if self.cfg.grad_clip is not None:
                grads, vs = zip(*optimizer.compute_gradients(self.loss))
                grads, _ = tf.clip_by_global_norm(grads, self.cfg.grad_clip)
                self.train_op = optimizer.apply_gradients(zip(grads, vs))
            else:
                self.train_op = optimizer.minimize(self.loss)

    # dataset_name=0表示"20news", "ling_spam", "imdb", "cornell"这四种数据集
    # dataset_name=1表示sst1等数据集
    def train(self, trainset, devset, testset, dataset_name=1, batch_size=64, epochs=50, shuffle=True):
        self.logger.info("Start training...")
        init_lr = self.cfg.lr  # 初始的学习率
        best_score = 0.0  # 最高的得分
        best_score_epoch = 1  # 最高得分的轮数
        best_report = None
        no_imprv_epoch = 0  # 不再上升的轮数
        acc_list,loss_list = [],[]
        loss_dict = dict()
        for epoch in range(self.start_epoch, epochs + 1):
            self.logger.info("Epoch %2d/%2d:" % (epoch, epochs))
            if shuffle:
                np.random.shuffle(trainset)  # 打乱训练数据集的顺序
            # training each epoch
            # words的格式为[[(21, 45), ([chars_idx...])], [...]]
            # labels是one-hot的结果
            # batch_iter用于计算batch 需要的轮数，返回对应的数据
            for i, (sentences, labels) in enumerate(batch_iter(trainset, batch_size, dataset_name=dataset_name)):
                if len(sentences) != batch_size:
                    break
                feed_dict = self._get_feed_dict(sentences, dataset_name=dataset_name, labels=labels, lr=self.cfg.lr,
                                                is_train=True)
                _, train_loss = self.sess.run([self.train_op, self.loss], feed_dict=feed_dict)
                loss_list.append(float(train_loss))
            if devset is not None:
                self.evaluate(devset, batch_size, dataset_name=dataset_name)
            cur_score, report = self.evaluate(testset, batch_size, dataset_name=dataset_name, is_devset=False)
            acc_list.append(cur_score)
            # learning rate decay(学习率是否衰变)
            if self.cfg.decay_lr:
                self.cfg.lr = init_lr / (1 + self.cfg.lr_decay * epoch)
            if cur_score > best_score:
                no_imprv_epoch = 0
                self.save_session(epoch)
                best_score = cur_score
                best_score_epoch = epoch
                best_report = report
                self.logger.info(' -- new BEST score on TEST dataset: {:05.3f}'.format(best_score))
            else:
                no_imprv_epoch += 1
                if no_imprv_epoch >= self.cfg.no_imprv_patience:
                    self.logger.info('early stop at {}th epoch without improvement for {} epochs, BEST score: '
                                     '{:05.3f} at epoch {}'.format(epoch, no_imprv_epoch, best_score, best_score_epoch))
                    break
        print(acc_list)
        loss_dict["losses"] = loss_list
        loss_dict["best_score"] = best_score
        loss_dict["accuracy_list"] = acc_list
        report_deal = deal_with_report(best_report)
        loss_dict["report"] = report_deal
        self.logger.info("Best score on Test dataset: {} epoch is {:05.3f}".format(best_score_epoch, best_score))
        self.logger.info('Training process done...')
        return loss_dict

    def evaluate(self, dataset, batch_size, dataset_name=1, is_devset=True):
        accuracies = []
        y_pre, y = [], []
        report = None
        for words, labels in batch_iter(dataset, batch_size, dataset_name=dataset_name):
            if len(words) != batch_size:
                break
            feed_dict = self._get_feed_dict(words, dataset_name=dataset_name, labels=labels, lr=None, is_train=False)
            predictions, accuracy = self.sess.run([self.predictions, self.accuracy], feed_dict=feed_dict)
            y_pre.extend(np.argmax(predictions, 1))
            y.extend(np.argmax(labels, 1))
            accuracies.append(accuracy)
        acc = np.mean(accuracies) * 100
        if is_devset == False:
            report = classification_report(y, y_pre, digits=4)
            print(report)
        self.logger.info("Testing model over {} dataset: accuracy - {:05.3f}".format('DEVELOPMENT' if is_devset else
                                                                                     'TEST', acc))
        return acc,report